import './App.css';
import Navbar from './Component/Navbar';
import Header from './Component/Header';
import Card from './Component/Card';
import FAQ from './Component/FAQ';
import Footer from './Component/Footer';

function App() {
  return (
    <div className="App">
     
     <Navbar />
     <Header />
     <Card />
     <FAQ />
     <Footer />

    </div>
  );
}

export default App;
