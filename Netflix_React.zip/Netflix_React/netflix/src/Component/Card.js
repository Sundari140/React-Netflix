import React from 'react'
import img1 from '../Assets/feature-1.png'
import img2 from '../Assets/feature-2.png'
import img3 from '../Assets/feature-3.png'
import img4 from '../Assets/feature-4.png'


export default function Card() {
  return (
    <div className="card1 ">
          <div className="row flex flex-col md:flex-row">
            <div className="text-col md:w-1/2 flex">
                <h2>Enjoy on your TV.</h2>
                <p>Watch on smart TVs, Playstation ,xbox, Chromecast, Apple TV, Blu-ray players and more.</p>
            </div>
            <div className="img-col">
              <img src={img1} className='md:w-1/2'/>
        </div>
      </div>

          <div className="row">
            <div className="img-col">
              <img src={img2} />
            </div>
            <div className="text-col">
                <h2>Enjoy on your TV.</h2>
                <p>Watch on smart TVs, Playstation ,xbox, Chromecast, Apple TV, Blu-ray players and more.</p>
            </div>
        </div>


          <div className="row">
            <div className="text-col">
                <h2>Enjoy on your TV.</h2>
                <p>Watch on smart TVs, Playstation ,xbox, Chromecast, Apple TV, Blu-ray players and more.</p>
            </div>
            <div className="img-col">
              <img  src={img3}/>
        </div>
      </div>

          <div className="row">
            <div className="img-col">
              <img  src={img4} />
            </div>
            <div className="text-col">
                <h2>Enjoy on your TV.</h2>
                <p>Watch on smart TVs, Playstation ,xbox, Chromecast, Apple TV, Blu-ray players and more.</p>
            </div>
        </div>
      </div>
  )
}
