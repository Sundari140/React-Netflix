import React from 'react'
import '../App.css'


export default function FAQ() {
  return (
    <div className="ques">
    <h2>Frequently Asked Questions</h2>
    <ul className="accordian ">
<li>
<input type="radio" name="accordian" id="one"/>
<label>What is Netflix?</label>

</li>
<li>
<input type="radio" name="accordian" id="two"/>
<label>What is Netflix?</label>

</li>
<li>
<input type="radio" name="accordian" id="three"/>
<label>What is Netflix?</label>

</li>
<li>
<input type="radio" name="accordian" id="four"/>
<label>What is Netflix?</label>

</li>
<li>
<input type="radio" name="accordian" id="five"/>
<label>What is Netflix?</label>

</li>
<li>
<input type="radio" name="accordian" id="six"/>
<label>What is Netflix?</label>

</li>
</ul>
<small>Ready to watch? Enter your emailcto create or restart your membership.</small>
<form className="email-signup">
<input type="email" placeholder="Email address" required/>
<button type="submit">Get Started </button>
</form>
</div>
  )
}
