import React from 'react'

export default function Footer() {
  return (
    <footer className="footer">
<h2>Questions? call 000-000-000-000</h2>

<div className="row">
  
  <div className="col">
<a href="#">FAQ</a>
<a href="#">Investor Relation</a>
<a href="#">Privacy</a>
<a href="#">Speed test</a>
 </div>
 <div className="col">
  <a href="#">FAQ</a>
  <a href="#">Investor Relation</a>
  <a href="#">Privacy</a>
  <a href="#">Speed test</a>
   </div>
   <div className="col">
    <a href="#">FAQ</a>
    <a href="#">Investor Relation</a>
    <a href="#">Privacy</a>
    <a href="#">Speed test</a>
     </div>
     <div className="col">
      <a href="#">FAQ</a>
      <a href="#">Investor Relation</a>
      <a href="#">Privacy</a>
      <a href="#">Speed test</a>
       </div>

</div>
</footer>
  )
}
