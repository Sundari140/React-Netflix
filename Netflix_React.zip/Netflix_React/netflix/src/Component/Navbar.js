import React from 'react'
import '../App.css'
import logo from '../Assets/logo.png'


export default function Navbar() {
  return (
    <div className="header">
       <nav>
              <img className="logo" src={logo}/>
              <div>
                <button>English</button>
                <button>Sign Up</button>

              </div>
            </nav>

    </div>
  )
}
